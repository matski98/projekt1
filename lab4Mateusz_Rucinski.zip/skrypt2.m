%Mateusz Ruciński

G1=tf([1],[1 1 2]);%system1
G2=tf([1 0],[1 -0.1 1])%system2
nyquist(G2);%diagram Nyquista