%Mateusz Ruciński

sim('model3');
plot(x4);%wykres sumy sinusoid
grid on;
ylabel('x(t)');
legend('sinusoida po przefiltrowaniu','sinusoida');