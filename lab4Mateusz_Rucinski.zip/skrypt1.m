%Mateusz Ruciński

A=1;%Amplituda
B=0;%bias
ph=1;%faza
f=1;%częstotliwość
sim('model1.slx');
plot(simout);
grid on;
xlabel('t');
ylabel('x');