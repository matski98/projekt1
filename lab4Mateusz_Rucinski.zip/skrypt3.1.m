%Mateusz Ruciński

GD=tf([1],[4 1]);%filtr dolnoprzepustowy
GG=tf([0.4 0],[0.4 1]);%filtr dolnoprzepustowy
GP=tf([1 0],[1 2 1]);%filtr pasmoprzepustowy
G2=tf([1],[1 0.1 1]);%filtr 2 rzędu
bode(G2);
grid on;
