%Mateusz Ruciński

A=4;%amplituda
w=5;%częstotliwość
ph=0;%przesunięcie fazowe
sim('model2');
plot(x4);
grid on;
ylabel('x(t)');
legend('sinusoida po przefiltrowaniu','sinusoida');