%Mateusz Ruciński

%zad 1.
%{
WPC = 7;
tab=[-1.2, -1, -0.8, 0, 0.2, 1, 1.2];
open('model3_1');
for lambda=tab
    figure;
    hold on;
    sim('model3_1')
    for j=1:10
        plot(j,x(j),'o');
        xlabel('k');
        ylabel('x(k)');
        title(['Systen dyskretny dla lambdy: ', num2str(lambda)]);
    end
    hold off;
end
%}
%zad 2.
%{
WPC = 0;
h = 0.2;
I=7;
N=8;
A = [0 1 ; -I -N];
B = [0 ; 1];
C = eye(2);
D = [0 ; 0];

Ad = expm(h*A);
syms t;
Bd = double(int(expm(t*A)*B,t,0,h));
Cd = C;

open('model3_2');
sim('model3_2');
plot (dyskretny);
hold on;
plot(ciagly);
grid on;
legend('x dyskretne','y dyskretne','x ciągłe','y ciągłe');
xlabel('t');
ylabel('x(t)');
hold off;
%}

%zad 3.
%%{
K0 = 100000;
r = 0.08;
n = 5;
K = zeros(12,1);
for m=1:length(K)
    K(m)=K0*(1+r/m)^(m*n);
end 

figure;
hold on;
title('Wykres zależności liczby kapitalizacji w roku a kapitałem końcowym'); 
plot(K,'o');
xlabel('ilosc kapitalizacji w ciągu roku');
ylabel('koncowy kapitał');
hold off;
%}

%zad4
%{

f = @(x) x^3-2*(x^2)-11*x+12;
df = @(x) 3*x^2-4*x-11;

styczne(f,df,-1,1e-4,100);

%}