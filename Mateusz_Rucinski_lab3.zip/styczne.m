function styczne(f,df,start,tol,iteracje)
    x=start;
    for i=1:iteracje
        %display(x);
        if(abs(f(x))<tol)
            display(x);
            break;
        end
        x_next = x-f(x)/df(x);
        if(abs(x-x_next)<tol)
            display(x_next);
            break;
        end
        x = x_next;
    end
end
