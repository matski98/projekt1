
clear;
clc;
close all;

image = imread('ccl1.png');


indexated = indexate(image);

figure;
subplot(1,2,1);
imshow(label2rgb(indexated));
subplot(1,2,2);
imshow("ccl1Result.png");
